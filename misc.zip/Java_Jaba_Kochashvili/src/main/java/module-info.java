module com.example.java_jaba_kochashvili {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.java_jaba_kochashvili to javafx.fxml;
    exports com.example.java_jaba_kochashvili;
}