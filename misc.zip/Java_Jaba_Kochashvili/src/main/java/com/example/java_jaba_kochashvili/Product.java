package com.example.java_jaba_kochashvili;

public class Product {

    private final String name;
    private final double quantity;
    public Product(String name, Double quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public Double getQuantity() {
        return quantity;
    }
}
