package com.example.java_jaba_kochashvili;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class DB {
    static String url = "jdbc:sqlite:/Users/kochashvili/Developer/JVM/Java_Jaba_Kochashvili/products.sqlite";

        public static void insert(Product product) {


            Connection conn = null;
            try {
                conn = DriverManager.getConnection(url);
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

            String sql = "INSERT INTO products(name, quantity) VALUES(?, ?)";
            PreparedStatement pstmt = null;
            try {
                assert conn != null;
                pstmt = conn.prepareStatement(sql);
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

                try {
                    assert pstmt != null;
                    pstmt.setString(1, product.getName());
                    pstmt.setString(2, product.getQuantity().toString());
                    // execute the PreparedStatement object
                    pstmt.executeUpdate();
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
                try {
                pstmt.close();
                conn.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }

    public static ObservableList<PieChart.Data> getAllProducts() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        List<Product> products = new ArrayList<>();

        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM products");

            // loop through the result set and create Product objects
            while (rs.next()) {
                String name = rs.getString("name");
                double quantity = rs.getDouble("quantity");
                Product product = new Product(name, quantity);
                products.add(product);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        // close the connection and the statement object
        try {
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        // use the Stream API to transform the products into PieChart.Data objects
        // and collect them into an ObservableList
        return products.stream()
                .map(product -> new PieChart.Data(product.getName(), product.getQuantity()))
                .collect(Collectors.toCollection(FXCollections::observableArrayList));
    }

}


