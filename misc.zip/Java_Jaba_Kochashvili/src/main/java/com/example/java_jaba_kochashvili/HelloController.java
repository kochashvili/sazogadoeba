package com.example.java_jaba_kochashvili;

import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.TextField;

public class HelloController {
    @FXML
    private TextField Name;
    @FXML
    private TextField Quantity;
    @FXML
    private PieChart Chart;

    @FXML
    protected void onAddButtonClick() {
        Product product = new Product(Name.getText(), Double.parseDouble(Quantity.getText()));

        Name.clear();
        Quantity.clear();

        DB.insert(product);

        Chart.setData(DB.getAllProducts());
    }
}